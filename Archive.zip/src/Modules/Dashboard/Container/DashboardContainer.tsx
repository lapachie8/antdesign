import React from 'react';

export default function DashboardContainer() {
  return <div></div>;
}
