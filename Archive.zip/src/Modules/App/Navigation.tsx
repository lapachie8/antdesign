import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';

import DashboardContainer from '../Dashboard/Container/DashboardContainer';
import WithTemplate from './WithTemplate';

export default class Navigation extends Component {
  render() {
    const dashboard = WithTemplate(DashboardContainer);

    return (
      <Switch>
        <Route path="/" exact={true} component={dashboard} />
      </Switch>
    );
  }
}
