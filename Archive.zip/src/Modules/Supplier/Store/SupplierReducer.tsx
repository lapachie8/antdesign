import { Action } from 'redux';

export const initialState: any = {
  list: [],
  selectedSupplier: {},
  selectedIdSupplier: '',
  modalAction: 'register',
};

export default function SupplierReducer(state = initialState, action: Action) {
  if (!action) return state;
  //   const newState = Object.assign({}, state);
  switch (action.type) {
  }
  return state;
}
