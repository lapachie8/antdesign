import { Action } from 'redux';

export interface IToggleSider extends Action {
  status: boolean;
}

export function toggleSider(status = false): IToggleSider {
  return {
    type: 'TOGGLE_SIDER',
    status,
  };
}
