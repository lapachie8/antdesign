import { Action } from 'redux';
import { IToggleSider } from './TemplateAction';

export const initialState: any = {
  siderIsOpen: true,
};

export default function TemplateReducer(state = initialState, action: Action) {
  if (!action) return state;
  const newState = Object.assign({}, state);

  switch (action.type) {
    case 'TOGGLE_SIDER': {
      const toggleSider = action as IToggleSider;
      newState.siderIsOpen = toggleSider.status;
      // newState.siderIsOpen = !state.siderIsOpen;
      return { ...newState };
    }
  }
  return state;
}
