import { createSelector } from 'reselect';

const templateState = (state: any) => state.TemplateState;

export const sideIsOpenSelector = () =>
  createSelector(templateState, state => state.siderIsOpen);
